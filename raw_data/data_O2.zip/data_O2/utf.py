import os
from datetime import date, timedelta
from pathlib import Path
from time import sleep

import httpx

folder = Path.cwd() / "data"
print(folder)
folder.mkdir(exist_ok=True, parents=True)
start_date = date(2023, 1, 1)
url = "https://luftdaten.umweltbundesamt.de/api-proxy/measures/csv"
for i in range(365):
    current_date = start_date + timedelta(days=i)
    filepath = os.path.join(folder, current_date.isoformat() + ".csv")
    if os.path.exists(filepath):
        continue
    params = {
        "date_from": current_date.isoformat(),
        "time_from": "1",
        "date_to": current_date.isoformat(),
        "time_to": "24",
        "data[0][co]": "3",  # TODO
        "data[0][sc]": "2",  # TODO
        "lang": "de"
    }
    response = httpx.get(url, params=params, timeout=60)
    print(response.status_code)

    # Datei wird geschrieben TODO
    c = response.content.decode("utf-8")
    with open(filepath, "w", encoding="utf-8") as file:
        file.write(c)
    print("wrote file: " + filepath)

    sleep(5)